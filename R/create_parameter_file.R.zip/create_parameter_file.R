library(maptools)
library(rgdal)
library(PBSmapping)
library(Hmisc)
library(RColorBrewer)

need.plots<-FALSE
need.gagedefs<-FALSE

model.mode<-"PRMS"

# Remember, to display all palettes provided by the RCOlorBrewer package, try:
# display.brewer.all()

NLCD_data_grid <- system.file( "extdata", "get_PRMS_dimensions.R", package="prmsParameterizer")
HRU_grid       <- system.file( "extdata", "hru_18dec2008__2200_rotated.asc", package="prmsParameterizer" )
HRU_shapefile  <- system.file( "extdata", "hru_18dec2008__2200.shp", package="prmsParameterizer" )
NLCD_impervious_area_grid <- "nlcd_2001_imparea_rotated.asc"
hydrologic_soils_group_grid <- system.file( "extdata", "soils_rot_100m.asc", package="prmsParameterizer" )


# PROJ.4 string for the Wisconsin Transverse Mercator projection
proj4_components<-c("+proj=tmerc +lat_0=0.0",
                    "+lon_0=-90.0",
                    "+k=0.9996",
                    "+x_0=520000",
                    "+y_0=-4480000")

proj4string<-paste(proj4_components[1],proj4_components[2],
   proj4_components[3],proj4_components[4],proj4_components[5])

proj4_LL<-"+proj=latlong +ellps=GRS80 +datum=NAD83"

cell_area<-100.0*100.0

# "param_file" is the parameter definition file created by running
# gsflow or prms with the -print option enabled.
param_file<-"BEC_GSFLOW.control.par_name"
output_param_file<-"BEC.param"
output_template_file<-"BEC_pest.tpl"
output_par2par_file<-"BEC_par2par.tpl"


################################################################################
### READ IN DIMENSIONS, PARAMETERS
################################################################################


# call functions that read in output from PRMS with -print option
dims    <- get_prms_dimensions(param_file)
params  <- get_prms_parameters(param_file)

ndims   <- nrow(dims)
nparam  <- nrow(params)

################################################################################
### PARAMETERS to SKIP!!
################################################################################

skip.params<-c("gw_down_id","gw_pct_up","gw_strmseg_down_id","gw_up_id",
  "hru_down_id","hru_pct_up","hru_strmseg_down_id","hru_up_id","hru_type")

################################################################################
### HARD-WIRED DIMENSIONS                 {calculated by Weasel / R-Script}
################################################################################
ncascdgw<-909
ncascade<-824
ngwcell<-107440
nhrucell<-107440
nreach<-3465
nsegment<-74
ngwcol<-340
ngwrow<-316
nrain<-13

################################################################################
### HARD-WIRED VALUES
################################################################################

# these values were all derived in a separate process outside of this R script...

# from Lauren's LUCA optimization 1/21/2009
dday_slope<-c(0.42054638301455516,0.5352773624464393,0.5843461713578582,
   0.6612202416304971,0.7069521669585153,0.8427099902131139,1.079185217862937,
   0.8915926406590332,0.7127662803048602,0.6011786121726775,
   0.6170401063401411,0.4377967605399593)

# from Lauren's LUCA optimization 1/21/2009
dday_intcp<-c(-7.402843612877646,-12.555319256056151,-18.922575862785592,
   -26.592341228919977,-39.331738850226614,-58.07924544239732,-79.8655241248004,
   -65.09555365666259,-45.60418048108759,-30.81419351804422,
   -21.886741017460864,-12.555319256056151)

jh_coef<- c(0.0050,0.0082,0.0099,0.0096,0.0089,0.0083,0.0085,0.0089,0.0095,0.0102,0.0095,0.0052)  # Lauren LUCA adjustments

subbasin_down<-c(0,1,2,2,1,0)
radadj_intcp<-0.273       # determined by calibrating to Dane County observed radiation
radadj_slope<-0.0126
melt_look<-1
tmax_index<-rep(53.905550468189105,12)  # fm Lauren's LUCA optimization
freeh2o_cap<-0.05
tsta_elev<-887            # Madison Dane County Reg APT elev in feet
tmax_allsnow<-32.0
settle_const<-0.1
snarea_curve<-c(0.05,0.23,.40,0.52,0.64,0.75,0.81,0.87,0.93,0.99,1.0)
basin_area<-nhrucell*cell_area / 4046.825

# based on Randy's existing SFR implementation
numreach_segment<-c(21,16,117,69,50,57,10,107,24,50,38,100,185,12,1,72,35,
  36,35,12,11,19,5,4,24,17,17,22,84,61,14,57,24,29,69,26,43,53,44,20,19,13,
  9,13,81,71,155,58,76,29,20,83,7,7,27,40,16,28,142,24,39,65,44,98,20,
  63,94,20,8,111,83,124,73,15)

mxsziter<-25

# precip_dist2_prms parameters
psta_xlong<-c(1.88336E+06,1.76156E+06,1.76612E+06,1.77738E+06,1.79656E+06,
  1.78909E+06,1.78673E+06,1.80676E+06,1.81323E+06,1.81273E+06,1.80200E+06,
  1.79747E+06,1.83652E+06)

psta_ylat<-c(9.75581E+05,9.85155E+05,9.71238E+05,9.70276E+05,9.55624E+05,
  9.54129E+05,9.45250E+05,9.69304E+05,9.75827E+05,9.83256E+05,9.64955E+05,
  9.62464E+05,9.59433E+05)

################################################################################
### FUNCTION DEFINITIONS
################################################################################

# note: most of these functions could really be replaced with a simple table lookup
#       routine; the idea behind these functions is to assign PRMS parameter values
#       on the basis of the majority landuse, vegetation type, etc. for the HRU

NLCD_to_cov_type<-function(x) {

  n<-length(x)
  y<-numeric(n)
  y <- rep(0,n)   # cov_type is ZERO unless explicitly stated otherwise...

  y[x==21] <- 2                           # OPEN SPACE
  y[x==22] <- 1                           # DEVELOPED, LOW-INTENSITY
  y[x==23] <- 1                           # DEVELOPED, MED-INTENSITY
  y[x==24] <- 0                           # DEVELOPED, HIGH-INTENSITY
  y[x==41] <- 3                           # DECIDUOUS FOREST
  y[x==42] <- 3                           # EVERGREEN FOREST
  y[x==43] <- 3                           # MIXED FOREST
  y[x==52] <- 2                           # SHRUB/SCRUB
  y[x>70 & x<90] <- 1                     # HERBACEOUS/CROPS/PASTURE
  y[x==90] <- 3                           # WOODED WETLAND
  y[x==95] <- 2                           # EMERGENT WETLAND

  return(y)

}

NLCD_to_rooting_depth<-function(x) {

  n<-length(x)
  y<-numeric(n)
  y <- rep(0,n)   # rooting depth is ZERO unless explicitly stated otherwise...

  y[x==21] <- 0.5                       # OPEN SPACE
  y[x==22] <- 1.0                       # DEVELOPED, LOW-INTENSITY
  y[x==23] <- 1.0                       # DEVELOPED, MED-INTENSITY
  y[x==24] <- 1.0                       # DEVELOPED, HIGH-INTENSITY
  y[x==41] <- 2.5                           # DECIDUOUS FOREST
  y[x==42] <- 2.5                           # EVERGREEN FOREST
  y[x==43] <- 2.5                           # MIXED FOREST
  y[x==52] <- 1.5                           # SHRUB/SCRUB
  y[x>70 & x<90] <- 1.5                     # HERBACEOUS/CROPS/PASTURE
  y[x==90] <- 2.5                           # WOODED WETLAND
  y[x==95] <- 2.5                           # EMERGENT WETLAND

  return(y)

}

NLCD_to_soil_depth<-function(x) {

  n<-length(x)
  y<-numeric(n)
  y <- rep(0,n)   # soil depth is ZERO unless explicitly stated otherwise...

  y[x==21] <- 1.5                       # OPEN SPACE
  y[x==22] <- 1.5                       # DEVELOPED, LOW-INTENSITY
  y[x==23] <- 1.5                       # DEVELOPED, MED-INTENSITY
  y[x==24] <- 1.5                       # DEVELOPED, HIGH-INTENSITY
  y[x==41] <- 3.0                       # DECIDUOUS FOREST
  y[x==42] <- 3.0                       # EVERGREEN FOREST
  y[x==43] <- 3.0                       # MIXED FOREST
  y[x==52] <- 1.5                       # SHRUB/SCRUB
  y[x>70 & x<90] <- 2.0                 # HERBACEOUS/CROPS/PASTURE
  y[x==90] <- 3.0                       # WOODED WETLAND
  y[x==95] <- 3.0                       # EMERGENT WETLAND

  return(y)

}

NLCD_to_covden_sum<-function(x) {

  n<-length(x)
  y<-numeric(n)
  y <- rep(0,n)   # covden_sum is ZERO unless explicitly stated otherwise...

  y[x==21] <- 0.01                       # OPEN SPACE
  y[x==22] <- 0.25                       # DEVELOPED, LOW-INTENSITY
  y[x==23] <- 0.15                       # DEVELOPED, MED-INTENSITY
  y[x==24] <- 0.10                       # DEVELOPED, HIGH-INTENSITY
  y[x==41] <- 1.                         # DECIDUOUS FOREST
  y[x==42] <- 1.                         # EVERGREEN FOREST
  y[x==43] <- 1.                         # MIXED FOREST
  y[x==52] <- 0.25                       # SHRUB/SCRUB
  y[x>70 & x<90] <- 0.15                 # HERBACEOUS/CROPS/PASTURE
  y[x==90] <- 1.0                        # WOODED WETLAND
  y[x==95] <- 0.25                       # EMERGENT WETLAND

  return(y)

}

NLCD_to_covden_win<-function(x) {

  n<-length(x)
  y<-numeric(n)
  y <- rep(0,n)   # covden_sum is ZERO unless explicitly stated otherwise...

  y[x==21] <- 0.01                       # OPEN SPACE
  y[x==22] <- 0.25                       # DEVELOPED, LOW-INTENSITY
  y[x==23] <- 0.15                       # DEVELOPED, MED-INTENSITY
  y[x==24] <- 0.10                       # DEVELOPED, HIGH-INTENSITY
  y[x==41] <- 0.4                        # DECIDUOUS FOREST
  y[x==42] <- 1.                         # EVERGREEN FOREST
  y[x==43] <- 0.7                        # MIXED FOREST
  y[x==52] <- 0.25                       # SHRUB/SCRUB
  y[x>70 & x<90] <- 0.15                 # HERBACEOUS/CROPS/PASTURE
  y[x==90] <- 1.0                        # WOODED WETLAND
  y[x==95] <- 0.25                       # EMERGENT WETLAND

  return(y)

}

NLCD_to_srain_intcp<-function(x) {

  n<-length(x)
  y<-numeric(n)
  y <- rep(0,n)   # srain_intcp is ZERO unless explicitly stated otherwise...

  y[x==21] <- 0.01                       # OPEN SPACE
  y[x==22] <- 0.04                       # DEVELOPED, LOW-INTENSITY
  y[x==23] <- 0.03                       # DEVELOPED, MED-INTENSITY
  y[x==24] <- 0.02                       # DEVELOPED, HIGH-INTENSITY
  y[x==41] <- 0.06                       # DECIDUOUS FOREST
  y[x==42] <- 0.09                       # EVERGREEN FOREST
  y[x==43] <- 0.075                        # MIXED FOREST
  y[x==52] <- 0.05                       # SHRUB/SCRUB
  y[x>70 & x<90] <- 0.04                 # HERBACEOUS/CROPS/PASTURE
  y[x==90] <- 0.08                       # WOODED WETLAND
  y[x==95] <- 0.05                       # EMERGENT WETLAND

  return(y)

}

NLCD_to_wrain_intcp<-function(x) {

  n<-length(x)
  y<-numeric(n)
  y <- rep(0,n)   # wrain_intcp is ZERO unless explicitly stated otherwise...

  y[x==21] <- 0.01                       # OPEN SPACE
  y[x==22] <- 0.04                       # DEVELOPED, LOW-INTENSITY
  y[x==23] <- 0.03                       # DEVELOPED, MED-INTENSITY
  y[x==24] <- 0.02                       # DEVELOPED, HIGH-INTENSITY
  y[x==41] <- 0.04                       # DECIDUOUS FOREST
  y[x==42] <- 0.09                       # EVERGREEN FOREST
  y[x==43] <- 0.06                       # MIXED FOREST
  y[x==52] <- 0.05                       # SHRUB/SCRUB
  y[x>70 & x<90] <- 0.04                 # HERBACEOUS/CROPS/PASTURE
  y[x==90] <- 0.08                       # WOODED WETLAND
  y[x==95] <- 0.05                       # EMERGENT WETLAND

  return(y)

}

NLCD_to_snow_intcp<-function(x) {

  n<-length(x)
  y<-numeric(n)
  y <- rep(0,n)   # snow_intcp is ZERO unless explicitly stated otherwise...

  y[x==21] <- 0.01                       # OPEN SPACE
  y[x==22] <- 0.03                       # DEVELOPED, LOW-INTENSITY
  y[x==23] <- 0.02                       # DEVELOPED, MED-INTENSITY
  y[x==24] <- 0.01                       # DEVELOPED, HIGH-INTENSITY
  y[x==41] <- 0.06                       # DECIDUOUS FOREST
  y[x==42] <- 0.1                        # EVERGREEN FOREST
  y[x==43] <- 0.08                       # MIXED FOREST
  y[x==52] <- 0.04                       # SHRUB/SCRUB
  y[x>70 & x<90] <- 0.01                 # HERBACEOUS/CROPS/PASTURE
  y[x==90] <- 0.06                       # WOODED WETLAND
  y[x==95] <- 0.04                       # EMERGENT WETLAND

  return(y)

}

soil_hyd_grp_to_soil_type<-function(x) {

  n<-length(x)
  y<-numeric(n)
  y <- rep(2,n)   # soil_type is TWO unless explicitly stated otherwise...

  y[x==1] <- 1                       # GROUP A
  y[x==2] <- 2                       # GROUP B
  y[x==3] <- 2                       # GROUP C
  y[x==4] <- 3                       # GROUP D

  return(y)

}

################################################################################
###  OVERRIDES for certain dimensions, parameters
################################################################################

dims$Value[dims$Name=="nobjfunc"]<-0
dims$Value[dims$Name=="nlapse"]<-1

cat(file=output_param_file,"Parameter file for PRMS/GSFLOW\n")
cat(file=output_template_file,"ptf &\nParameter file for PRMS/GSFLOW\n")

for (filename in c(output_param_file,output_template_file)) {
  cat(file=filename,"Version: 1.7\n",append=TRUE)
  cat(file=filename,"** Dimensions **\n",append=TRUE)
}

# BEGIN a new PAR2PAR file...
cat(file=output_par2par_file,"ptf &\n")
cat(file=output_par2par_file,"* parameter data\n",append=TRUE)

hru_sp<-maptools::readAsciiGrid(paste(grid_dir,"hru_18dec2008__2200_rotated.asc",sep=""),colname="hru")
hru_im<-maptools::readAsciiGrid(paste(grid_dir,"hru_18dec2008__2200_rotated.asc",sep=""),
   colname="hru",as.image=TRUE)

hru_ID<-sort(unique(hru_sp$hru))
nhru<-length(hru_ID)

hru<-data.frame(HRU=numeric(nhru),
                area=numeric(nhru),
                area.acres=numeric(nhru),
                elev.meters=numeric(nhru),
                elev.feet=numeric(nhru),
                slope.median=numeric(nhru),
                lu=numeric(nhru),
                cov_type=numeric(nhru),
                hydgrp=numeric(nhru),
                TIA=numeric(nhru),
                EIA=numeric(nhru),
                pct_imp=numeric(nhru),
                pct_D_soils=numeric(nhru),
                open_water=numeric(nhru),
                stringsAsFactors=FALSE)

hru$HRU<-hru_ID

hru_shp_sp<-maptools::readShapePoly(paste(shape_dir,"hru_18dec2008__2200.shp",sep=""),proj4string=CRS(proj4string))
hru_shp_sp$PID<-hru_shp_sp$ID
hru_shp_LL_sp<-spTransform(hru_shp_sp,CRS(proj4_LL))
#hru_dbf<-read.dbf(paste(shape_dir,"tp250h7dm_rotated.dbf",sep=""))
#hru_PB<-SpatialPolygons2PolySet(hru_shp_sp)
hru_shp_LL_PS<-SpatialPolygons2PolySet(hru_shp_LL_sp)
hru_shp_LL_PD<-as.PolyData(hru_shp_LL_sp@data)

SFR_sp<-maptools::readAsciiGrid(paste(grid_dir,"BEC_SFR.asc",sep=""),colname="segment")

hru$area.acres<-by(hru_sp$hru,hru_sp$hru,length)*cell_area / 4046.825
hru$area<-by(hru_sp$hru,hru_sp$hru,length)*cell_area

# LAND USE
nlcd_2001_sp<-maptools::readAsciiGrid(paste(grid_dir,"nlcd_2001_rotated.asc",sep=""),colname="lc")
nlcd_2001_im<-maptools::readAsciiGrid(paste(grid_dir,"nlcd_2001_rotated.asc",sep=""),colname="lc",as.image=TRUE)
land_use_codes<-unique(nlcd_2001_sp@data[[1]])
hru$lu<-as.numeric(by(nlcd_2001_sp$lc,hru_sp$hru,FUN=majority))
hru$cov_type<-NLCD_to_cov_type(hru$lu)
nlcd_2001_sp$covden_sum<-NLCD_to_covden_sum(nlcd_2001_sp$lc)
nlcd_2001_sp$covden_win<-NLCD_to_covden_win(nlcd_2001_sp$lc)
nlcd_2001_sp$srain_intcp<-NLCD_to_srain_intcp(nlcd_2001_sp$lc)
nlcd_2001_sp$wrain_intcp<-NLCD_to_wrain_intcp(nlcd_2001_sp$lc)
nlcd_2001_sp$snow_intcp<-NLCD_to_snow_intcp(nlcd_2001_sp$lc)
nlcd_2001_sp$rooting_depth<-NLCD_to_rooting_depth(nlcd_2001_sp$lc)
nlcd_2001_sp$soil_depth<-NLCD_to_soil_depth(nlcd_2001_sp$lc)

hru$covden_sum<-as.numeric(by(nlcd_2001_sp$covden_sum,hru_sp$hru,FUN=mean))
hru$covden_win<-as.numeric(by(nlcd_2001_sp$covden_win,hru_sp$hru,FUN=mean))
hru$srain_intcp<-as.numeric(by(nlcd_2001_sp$srain_intcp,hru_sp$hru,FUN=median))
hru$wrain_intcp<-as.numeric(by(nlcd_2001_sp$wrain_intcp,hru_sp$hru,FUN=median))
hru$snow_intcp<-as.numeric(by(nlcd_2001_sp$snow_intcp,hru_sp$hru,FUN=median))

# GAGEDEFS
gagedef_bec_sp<-maptools::readAsciiGrid(paste(grid_dir,"gagedef_bec_at_be.asc",sep=""),colname="bec_at_be")
#slope_sp$hru<-overlay(slope_sp,hru_shp_sp)
#hru_slope<-by(slope_sp$slope,slope_sp$hru,mean)
hru$bec_at_be<-by(gagedef_bec_sp$bec_at_be,hru_sp$hru,FUN=majority)

gagedef_bec_sp<-maptools::readAsciiGrid(paste(grid_dir,"gagedef_brewery_ck.asc",sep=""),colname="brewery_ck")
#slope_sp$hru<-overlay(slope_sp,hru_shp_sp)
#hru_slope<-by(slope_sp$slope,slope_sp$hru,mean)
hru$brewery_ck<-by(gagedef_bec_sp$brewery_ck,hru_sp$hru,FUN=majority)

gagedef_bec_sp<-maptools::readAsciiGrid(paste(grid_dir,"gagedef_garfoot_ck.asc",sep=""),colname="garfoot_ck")
#slope_sp$hru<-overlay(slope_sp,hru_shp_sp)
#hru_slope<-by(slope_sp$slope,slope_sp$hru,mean)
hru$garfoot_ck<-by(gagedef_bec_sp$garfoot_ck,hru_sp$hru,FUN=majority)

gagedef_bec_sp<-maptools::readAsciiGrid(paste(grid_dir,"gagedef_vermont_ck.asc",sep=""),colname="vermont_ck")
#slope_sp$hru<-overlay(slope_sp,hru_shp_sp)
#hru_slope<-by(slope_sp$slope,slope_sp$hru,mean)
hru$vermont_ck<-by(gagedef_bec_sp$vermont_ck,hru_sp$hru,FUN=majority)

gagedef_bec_sp<-maptools::readAsciiGrid(paste(grid_dir,"gagedef_bec_at_mazo.asc",sep=""),colname="bec_at_mazo")
#slope_sp$hru<-overlay(slope_sp,hru_shp_sp)
#hru_slope<-by(slope_sp$slope,slope_sp$hru,mean)
hru$bec_at_mazo<-by(gagedef_bec_sp$bec_at_mazo,hru_sp$hru,FUN=majority)

gagedef_bec_sp<-maptools::readAsciiGrid(paste(grid_dir,"gagedef_pheas_br.asc",sep=""),colname="pheas_br")
#slope_sp$hru<-overlay(slope_sp,hru_shp_sp)
#hru_slope<-by(slope_sp$slope,slope_sp$hru,mean)
hru$pheas_br<-by(gagedef_bec_sp$pheas_br,hru_sp$hru,FUN=majority)

# SLOPE
slope_sp<-maptools::readAsciiGrid(paste(grid_dir,"slope_rotated.asc",sep=""),colname="slope")
#slope_sp$hru<-overlay(slope_sp,hru_shp_sp)
#hru_slope<-by(slope_sp$slope,slope_sp$hru,mean)
hru$slope.median<-by(slope_sp$slope,hru_sp$hru,median)

# SSURGO Ksat
ksat_sp<-maptools::readAsciiGrid(paste(grid_dir,"SSURGO_Ksat_rotated.asc",sep=""),colname="Ksat")
ksat_sp$Ksat<-ksat_sp$Ksat/1.0E6*86400
ksat_im<-maptools::readAsciiGrid(paste(grid_dir,"SSURGO_Ksat_rotated.asc",sep=""),colname="Ksat",
  as.image=TRUE)
ksat_im$z<-ksat_im$z/1.0E6*86400
hru$ksat<-by(ksat_sp$Ksat,hru_sp$hru,FUN=median)


# SOIL HYD GROUP
soilhg_sp<-maptools::readAsciiGrid(paste(grid_dir,"soils_rot_100m.asc",sep=""),colname="hyd_grp")
#soilhg_sp$hru<-overlay(soilhg_sp,hru_shp_sp)
#hru_hydgrp<-by(soilhg_sp$hyd_grp,hru_sp$hru,function(x) quantile(x,probs=0.5))
hru$hydgrp<-by(soilhg_sp$hyd_grp,hru_sp$hru,FUN=majority)
soilhg_sp$soil_type<-soil_hyd_grp_to_soil_type(soilhg_sp$hyd_grp)
hru$soil_type<-by(soilhg_sp$soil_type,hru_sp$hru,FUN=majority)


for(i in 1:nhru) {
  hru$pct_D_soils[i]<-length(soilhg_sp$hyd_grp[soilhg_sp$hyd_grp==4 & hru_sp$hru == i & nlcd_2001_sp$lc!=11])*cell_area / as.numeric(hru$area[i]) * 100.
  hru$pct_open_water[i]<-length(nlcd_2001_sp$lc[nlcd_2001_sp$lc==11 & hru_sp$hru == i])*cell_area / as.numeric(hru$area[i]) * 100.
}

# IMPERVIOUS AREA
imp_area_sp<-maptools::readAsciiGrid(paste(grid_dir,"nlcd_2001_imparea_rotated.asc",sep=""),colname="imp_area")
imp_area_im<-maptools::readAsciiGrid(paste(grid_dir,"nlcd_2001_imparea_rotated.asc",sep=""),
   as.image=TRUE,colname="imp_area")
hru$TIA<-by(imp_area_sp$imp_area,hru_sp$hru,FUN=sum)*cell_area / hru$area
# Alley and Veenhuis, 1983
hru$EIA<-0.15*hru$TIA^1.41
hru$pct_imp<-hru$EIA

# ELEVATION
elevation_sp<-maptools::readAsciiGrid(paste(grid_dir,"dem_rot.asc",sep=""),colname="elev_m")
elevation_im<-maptools::readAsciiGrid(paste(grid_dir,"dem_rot.asc",sep=""),colname="elev_m",
  as.image=TRUE)
hru$elev.meters<-by(elevation_sp$elev_m,hru_sp$hru,FUN=median)
hru$elev.feet<-hru$elev.meters * 3.28083

# GW Table
water_table_sp<-maptools::readAsciiGrid(paste(grid_dir,
   "dane_and_iowa_county_water_table_elevation_feet_ROTATED.asc",sep=""),colname="elev_ft")
water_table_im<-maptools::readAsciiGrid(paste(grid_dir,
   "dane_and_iowa_county_water_table_elevation_feet_ROTATED.asc",sep=""),colname="elev_ft",
   as.image=TRUE)
hru$water_table_feet<-by(water_table_sp$elev_ft,hru_sp$hru,FUN=median)
hru$depth2gw<-hru$elev.feet - hru$water_table_feet
hru$depth2gw[hru$depth2gw<0]<-0.1

# AVAILABLE WATER CONTENT
awc_sp<-maptools::readAsciiGrid(paste(grid_dir,"bec_awc_ssurgo_MODEL_DOMAIN_wtm_rotated.asc",sep=""),
   colname="awc")
awc_sp$awc<-awc_sp$awc*30.48/2.54   # convert from cm/cm to inches/foot
awc_im<-maptools::readAsciiGrid(paste(grid_dir,"bec_awc_ssurgo_MODEL_DOMAIN_wtm_rotated.asc",sep=""),
   colname="awc",as.image=TRUE)
awc_im$z<-awc_im$z*30.48/2.54   # convert from cm/cm to inches/foot
hru$awc<-as.numeric(by(awc_sp$awc,hru_sp$hru,FUN=median))
nlcd_2001_sp$ET_capacity<-nlcd_2001_sp$rooting_depth*awc_sp$awc
nlcd_2001_sp$water_capacity<-nlcd_2001_sp$soil_depth*awc_sp$awc

# ASPECT
aspect_sp<-maptools::readAsciiGrid(paste(grid_dir,"aspect_rotated.asc",sep=""),
   colname="aspect")
aspect_im<-maptools::readAsciiGrid(paste(grid_dir,"aspect_rotated.asc",sep=""),
   colname="aspect",as.image=TRUE)
hru$aspect<-by(aspect_sp$aspect,hru_sp$hru,FUN=median)

# SAGA Wetness Index
SAGA_wetness_index_sp<-maptools::readAsciiGrid(paste(grid_dir,"SAGA_wetness_index_rotated.asc",sep=""),
   colname="wetness_index")
SAGA_wetness_index_im<-maptools::readAsciiGrid(paste(grid_dir,"SAGA_wetness_index_rotated.asc",sep=""),
   colname="wetness_index",as.image=TRUE)
hru$SAGA_wetness_index<-by(SAGA_wetness_index_sp$wetness_index,hru_sp$hru,FUN=median)
hru$SAGA_wetness_index <- (hru$SAGA_wetness_index - min(hru$SAGA_wetness_index)) /
                           (max(hru$SAGA_wetness_index) - min(hru$SAGA_wetness_index))

# SUBBASIN ASSIGNMENTS
subbasin_sp<-maptools::readAsciiGrid(paste(grid_dir,"subbasin_all.asc",sep=""),
  colname="subbasin")
subbasin_im<-maptools::readAsciiGrid(paste(grid_dir,"subbasin_all.asc",sep=""),
  colname="subbasin",as.image=TRUE)
hru$subbasin<-by(subbasin_sp$subbasin,hru_sp$hru,FUN=majority)

# FOREST COVER
forest_sp<-maptools::readAsciiGrid(paste(grid_dir,"nlcd_2001_forest_rotated.asc",sep=""),
   colname="forest.pct")
forest_im<-maptools::readAsciiGrid(paste(grid_dir,"nlcd_2001_forest_rotated.asc",sep=""),
   colname="forest.pct",as.image=TRUE)
hru$forest.pct<-by(forest_sp$forest.pct,hru_sp$hru,FUN=sum)*cell_area / hru$area

# some handy maximum values
max_depth2gw<-max(hru$depth2gw)
max_slope<-max(hru$slope)
max_ksat<-max(hru$ksat)

### Surface runoff parameters
#hru$carea_max<-(hru$pct_open_water + hru$pct_D_soils)/100.
hru$carea_max<- 0.4 * (hru$SAGA_wetness_index)
#hru$smidx_coef<-hru$pct_open_water/100.
hru$smidx_coef<-0.015 * (hru$SAGA_wetness_index)
#hru$smidx_coef<-rep(0.0,nrow(hru))
#hru$smidx_exp<-0.2+(0.1*(1.0-hru$forest.pct/100.))
hru$smidx_exp<-0.2+(0.08 * hru$SAGA_wetness_index)
#hru$smidx_exp<-rep(0.22,nrow(hru))

### Soil reservoir parameters
#hru$sat_threshold <- (2.5 - (1.*hru$depth2gw/max_depth2gw) - (1.*hru$slope/max_slope))
hru$sat_threshold <- rep(999.,nrow(hru))
#hru$sat_threshold[hru$pct_open_water < 1.] <- (3.5
#      - (1.*hru$depth2gw[hru$pct_open_water < 1.]/max_depth2gw)
#      - (1.*hru$slope[hru$pct_open_water < 1.]/max_slope))
#hru$sat_threshold<- 4.0 * (1.0 - hru$SAGA_wetness_index) + 0.6
hru$soil_moist_max<-as.numeric(by(nlcd_2001_sp$water_capacity,hru_sp$hru,FUN=median))*0.6
hru$soil_rechr_max<-hru$soil_moist_max*0.666666667
hru$soil_moist_init<-hru$soil_moist_max
hru$soil_rechr_init<-hru$soil_rechr_max

# see Frankenberger (1999) for details
#hru$slowcoef_lin <- 0.02 * (1.0 - hru$depth2gw/max_depth2gw)
#hru$fastcoef_lin <- 0.125 * (1.0 - hru$depth2gw/max_depth2gw)
#hru$slowcoef_sq <- 0.1 * (1.0 - hru$depth2gw/max_depth2gw) + 0.01
#hru$fastcoef_sq <- 0.7 * (1.0 - hru$depth2gw/max_depth2gw) + 0.01
hru$slowcoef_lin <- 0.001 * (1.0 - hru$depth2gw/max_depth2gw)
hru$fastcoef_lin <- 0.1 * (1.0 - hru$depth2gw/max_depth2gw)
hru$slowcoef_sq <- 0.01 * (1.0 - hru$depth2gw/max_depth2gw) + 0.01
hru$fastcoef_sq <- 0.8 * (1.0 - hru$depth2gw/max_depth2gw) + 0.01
soil2gw_max<-rep(1,nrow(hru))

### Groundwater reservoir parameters
if(model.mode!="GSFLOW") {
  hru$ssr2gw_rate <- 0.1 * (hru$depth2gw/max_depth2gw + 0.01) +  0.05 * sqrt(hru$ksat/max_ksat) + 0.01
  hru$ssr2gw_exp <- 0.5 + 1.0 * (hru$depth2gw/max_depth2gw) +  1.0 * sqrt(hru$ksat/max_ksat)
  hru$ssrmax_coef <- rep(1.0,nrow(hru))
  hru$pref_flow_den <- 0.05 * (1.0 - hru$depth2gw/max_depth2gw) + 0.01
} else {
  hru$ssr2gw_rate <- 0.05 * (hru$depth2gw/max_depth2gw + 0.01) +  0.025 * sqrt(hru$ksat/max_ksat) + 0.01
  hru$ssr2gw_exp <- 0.75 + 0.75 * (hru$depth2gw/max_depth2gw) +  0.75 * sqrt(hru$ksat/max_ksat)
  hru$ssrmax_coef <- rep(1.0,nrow(hru))
  hru$pref_flow_den <- 0.15 * (1.0 - hru$depth2gw/max_depth2gw) + 0.05
}
#hru$gwflow_coef <- 0.03 * sqrt(hru$ksat/max_ksat) + 0.03 * (hru$depth2gw/max_depth2gw)
hru$gwflow_coef <- 0.02 * sqrt(hru$ksat/max_ksat) + 0.05 * (hru$depth2gw/max_depth2gw)
#hru$gwflow_coef[hru$depth2gw > 50] <- 0.1
gwstor_init<- 5.0  - 3.0 * (hru$depth2gw/max_depth2gw)
#gwstor_init<-rep(25.0,nrow(hru))

### TMAX and TMIN adjustments
#hru$tmax_adj<- -cos(hru$aspect/360*2*pi) * (hru$slope) * 20.0 * (1. - hru$forest.pct/100.)
hru$tmax_adj<- -cos((hru$aspect+45.)/360*2*pi) * 1.8 - (2. * hru$forest.pct/100.)
hru$tmax_adj[hru$aspect<0]<-0.  # no adjustment if flat
hru$tmax_adj[hru$tmax_adj<0]<-hru$tmax_adj[hru$tmax_adj<0] * 0.75
hru$tmax_adj<-hru$tmax_adj + 0.520   # Lauren LUCA adjustment
#hru$tmin_adj<- -cos(hru$aspect/360*2*pi) * (hru$slope) * 20.0 * (1. - hru$forest.pct/100.)
hru$tmin_adj<- -cos((hru$aspect+45.)/360*2*pi) * 1.8 - (2. * hru$forest.pct/100.)
hru$tmin_adj[hru$aspect<0]<-0.  # no adjustment if flat
hru$tmin_adj[hru$tmin_adj<0]<-hru$tmin_adj[hru$tmin_adj<0] * 0.75
hru$tmin_adj <- hru$tmin_adj - 0.565  # Lauren LUCA adjustment
hru$rad_trncf<- 0.35 + (1. - hru$forest.pct/100.) * 0.35

### PET parameters
jh_coef_hru<-rep(5.0,nrow(hru))

################################################################################
# PRECIP ADJUSTMENTS                                                           #
################################################################################
#snow_adj<-rep(1.35,nrow(hru)*12) - 0.208  # Lauren LUCA adjustment
snow_adj<-rep(1.1422445820550298,nrow(hru)*12)
#rain_adj<-rep(1.1,nrow(hru)*12) - 0.036   # Lauren LUCA adjustment
rain_adj<-rep(1.0639614373922175,nrow(hru)*12)
adjmix_rain<-rep(1.0,12)
snarea_thresh<-rep(1.0,nrow(hru))
snowinfil_max<- 1.0 * (hru$depth2gw/max_depth2gw + 0.01) +  0.75 * sqrt(hru$ksat/max_ksat) + 0.1

# precip_dist2_prms parameters
maxmon_prec<-rep(12.0,12)         # maximum monthly precip; numbers above this assumed in error
max_psta<-50                      # maximum number of precip stations to distribute
dist_max<-100000000               # maximum distance from HRU to include a precip station
ppt_adj<-rep(1.0,nrow(hru))
rain_mon<-rep(1.1,nrow(hru)*12)
snow_mon<-rep(1.35,nrow(hru)*12)
psta_mon<-rep(1.0,nrain*12)

# HRU LATITUDE
LL<-calcCentroid(hru_shp_LL_PS)
hru$hru_lat=as.numeric(by(LL$Y[LL$SID==1],hru_shp_LL_PD$GRIDCODE,mean))

# finally, remove the negative values
hru$aspect[hru$aspect<0]<-0.

################################################################################
## GVR parameters (GSFLOW only)
################################################################################
hrucell<-data.frame(gvr_cell_id=numeric(nhrucell),
                    gvr_cell_pct=numeric(nhrucell),
                    gvr_hru_id=numeric(nhrucell),
                    gvr_hru_pct=numeric(nhrucell))

# calculate number of MODFLOW cells in a given HRU
hru$num_MF_cells<-by(hru_sp$hru,hru_sp$hru,length)
hru$gvr_hru_pct<- 1.0/hru$num_MF_cells

hrucell$gvr_cell_id<-1:nhrucell
hrucell$gvr_cell_pct<-rep(1.0,nhrucell)
hrucell$gvr_hru_id<-hru_sp$hru
#hrucell$gvr_hru_pct<-rep(1.0,nhrucell)   !! BAD BAD BAD !!!
#hrucell$gvr_hru_pct<-rep(hru$gvr_hru_pct,hru$num_MF_cells)  ALSO BAD BAD BAD BAD BAD!!!!

for(i in 1:nhru) {
  hrucell$gvr_hru_pct[hrucell$gvr_hru_id==i]<-rep(hru$gvr_hru_pct[hru$HRU==i],
      hru$num_MF_cells[hru$HRU==i])
}

gwcell<-data.frame(gwc_col=numeric(ngwcell),
                   gwc_row=numeric(ngwcell))

gwcell$gwc_col<-rep(1:ngwcol,ngwrow)
gwcell$gwc_row<-rep(1:ngwrow,ngwcol)

################################################################################
## REACH parameters (GSFLOW only)
################################################################################

hru$hru_segment<-by(SFR_sp$segment,hru_sp$hru,FUN=majority)
hru$hru_segment[is.na(hru$hru_segment)]<-rep(0,length(hru$hru_segment[is.na(hru$hru_segment)]))

reach<-data.frame(reach_segment=numeric(nreach),
                  segment_pct_area=numeric(nreach),
                  local_reachid=numeric(nreach))

segment<-data.frame(numreach_segment=numeric(nsegment))

segment$numreach_segment<-numreach_segment

reach$local_reachid<-sequence(numreach_segment)
reach$reach_segment<-rep(1:nsegment,numreach_segment)
reach$segment_pct_area<-rep(1./segment$numreach_segment,numreach_segment)

if(need.plots) {

  # copy HRU attributes back into shapefile data structure for plotting
  for(i in 1:nhru) {
    mask<-hru_shp_sp@data$GRIDCODE==i
    hru_shp_sp$forest.pct[mask]<-hru$forest.pct[i]
    hru_shp_sp$aspect[mask]<-hru$aspect[i]
    hru_shp_sp$slope[mask]<-hru$slope.median[i]
    hru_shp_sp$awc[mask]<-hru$awc[i]
    hru_shp_sp$pct_D_soils[mask]<-hru$pct_D_soils[i]
    hru_shp_sp$soil_type[mask]<-hru$soil_type[i]
    hru_shp_sp$pct_imp[mask]<-hru$pct_imp[i]
    hru_shp_sp$pct_open_water[mask]<-hru$pct_open_water[i]
    hru_shp_sp$carea_max[mask]<-hru$carea_max[i]
    hru_shp_sp$smidx_coef[mask]<-hru$smidx_coef[i]
    hru_shp_sp$smidx_exp[mask]<-hru$smidx_exp[i]
    hru_shp_sp$covden_sum[mask]<-hru$covden_sum[i]
    hru_shp_sp$covden_win[mask]<-hru$covden_win[i]
    hru_shp_sp$srain_intcp[mask]<-hru$srain_intcp[i]
    hru_shp_sp$wrain_intcp[mask]<-hru$wrain_intcp[i]
    hru_shp_sp$snow_intcp[mask]<-hru$snow_intcp[i]
    hru_shp_sp$depth2gw[mask]<-hru$depth2gw[i]
    hru_shp_sp$soil_rechr_max[mask]<-hru$soil_rechr_max[i]
    hru_shp_sp$soil_moist_max[mask]<-hru$soil_moist_max[i]
    hru_shp_sp$sat_threshold[mask]<-hru$sat_threshold[i]
    hru_shp_sp$tmax_adj[mask]<-hru$tmax_adj[i]
    hru_shp_sp$tmin_adj[mask]<-hru$tmin_adj[i]
    hru_shp_sp$rad_trncf[mask]<-hru$rad_trncf[i]
    hru_shp_sp$bec_at_be[mask]<-hru$bec_at_be[i]
    hru_shp_sp$slowcoef_lin[mask]<-hru$slowcoef_lin[i]
    hru_shp_sp$fastcoef_lin[mask]<-hru$fastcoef_lin[i]
    hru_shp_sp$fastcoef_sq[mask]<-hru$fastcoef_sq[i]
    hru_shp_sp$slowcoef_sq[mask]<-hru$slowcoef_sq[i]
    hru_shp_sp$ssr2gw_rate_lin[mask]<-hru$ssr2gw_rate[i]
  }

  SFR_PS<-SpatialPolygons2PolySet(SFR_shp_sp)
  SFR_PD<-as.PolyData(SFR_shp_sp@data)

} # end if (need.plots)

hru_shp_PS<-SpatialPolygons2PolySet(hru_shp_sp)
hru_shp_PD<-as.PolyData(hru_shp_sp@data)

# now calc X and Y coord for HRU
XY<-calcCentroid(hru_shp_PS)
hru$hru_xlong=as.numeric(by(XY$X[XY$SID==1],hru_shp_PD$GRIDCODE,mean))*3.2808     # converting to feet!!
hru$hru_ylat=as.numeric(by(XY$Y[XY$SID==1],hru_shp_PD$GRIDCODE,mean))*3.2808      # converting to feet!!

# create sorted versions for output
dims.sort<-dims[order(dims$Name),]
params.sort<-params[order(params$Module,params$Dimname_1,params$Name),]

for(i in 1:ndims) {

  # overwrite the old dimension values with the GIS-determined values
  if(dims.sort$Name[i]=="nhru") {
    values<-nhru
    dims.sort$Value[i]<-nhru
  } else if(dims.sort$Name[i]=="ngw") {
    values <- nhru
    dims.sort$Value[i]<-nhru
  } else if(dims.sort$Name[i]=="nssr") {
    values <- nhru
    dims.sort$Value[i]<-nhru
  } else if(dims.sort$Name[i]=="nhrucell") {
    values <- nhrucell
    dims.sort$Value[i]<-nhrucell
  } else if(dims.sort$Name[i]=="ngwcell") {
    values <- ngwcell
    dims.sort$Value[i]<-ngwcell
  } else if(dims.sort$Name[i]=="nreach") {
    values <- nreach
    dims.sort$Value[i]<-nreach
  } else if(dims.sort$Name[i]=="nsegment") {
    values <- nsegment
    dims.sort$Value[i]<-nsegment
  } else if(dims.sort$Name[i]=="ncascade") {
    values <- ncascade
    dims.sort$Value[i]<-ncascade
  } else if(dims.sort$Name[i]=="ncascdgw") {
    values <- ncascdgw
    dims.sort$Value[i]<-ncascdgw
  } else {
    values<-dims.sort$Value[i]
  }
  write_prms_dimension(output_param_file,dims.sort$Name[i],values)
  write_prms_dimension(output_template_file,dims.sort$Name[i],values)
}

# insert line denoting start of PARAMETERS section of output file
cat(file=output_param_file,"** Parameters **\n",append=TRUE)
cat(file=output_template_file,"** Parameters **\n",append=TRUE)

for(i in 1:nparam) {

  values<-rep(params.sort$Default[i],params.sort$Size[i])
  if(params.sort$Dimname_1[i]=="nhru" & params.sort$Dimname_2[i]=="nmonths") {
    values<-rep(params.sort$Default[i],as.numeric(dims.sort$Value[dims.sort$Name=="nhru"])*12)
  } else if(params.sort$Dimname_1[i]=="nhru" | params.sort$Dimname_1[i]=="nssr"
     | params.sort$Dimname_1[i]=="ngw") {
    values<-rep(params.sort$Default[i],dims.sort$Value[dims.sort$Name=="nhru"])
  }

  par2par.txt<-NA
  tpl.txt<-NA

  if(params.sort$Name[i]=="hru_elev") {                     # hru_elev
    values<-hru$elev.feet
  } else if(params.sort$Name[i]=="elev_units") {            # elev_units
    values <- 0
  } else if(params.sort$Name[i]=="hru_aspect") {            # hru_aspect
    values <- hru$aspect
  } else if(params.sort$Name[i]=="hru_percent_imperv") {    # hru_percent_imperv
    values <- hru$pct_imp / 100.
  } else if(params.sort$Name[i]=="cov_type") {              # cov_type
    values <- hru$cov_type
  } else if(params.sort$Name[i]=="carea_max") {             # carea_max
    values <- hru$carea_max
  } else if(params.sort$Name[i]=="smidx_coef") {            # smidx_coef
    values <- hru$smidx_coef
    tpl.txt<-paste("&  smdx",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("smdx%i = %.5f * smdx_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"smdx_fac = &   smdx_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="smidx_exp") {             # smidx_exp
    values <- hru$smidx_exp
    tpl.txt<-paste("&  smdxe",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("smdxe%i = %.5f * smdxe_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"smdxe_fac = &   smdxe_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="hru_area") {              # hru_area
    values <- hru$area.acres
  } else if(params.sort$Name[i]=="hru_slope") {             # hru_slope
    values <- hru$slope.median
  } else if(params.sort$Name[i]=="hru_ssres") {             #hru_ssres
    values <- hru$hru
  } else if(params.sort$Name[i]=="hru_gwres") {             #hru_gwres
    values <- hru$hru
  } else if(params.sort$Name[i]=="srain_intcp") {           #srain_intcp
    values <- hru$srain_intcp
    tpl.txt<-paste("&  srnint",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("srnint%i = %.5f * srnint_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"srnint_fac = &   srnint_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="wrain_intcp") {           #wrain_intcp
    values <- hru$wrain_intcp
    tpl.txt<-paste("&  wrnint",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("wrnint%i = %.5f * wrnint_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"wrnint_fac = &   wrnint_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="snow_intcp") {            #snow_intcp
    values <- hru$snow_intcp
    tpl.txt<-paste("&  snint",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("snint%i = %.5f * snint_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"snint_fac = &   snint_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="soil_type") {             #soil_type
    values <- hru$soil_type
  } else if(params.sort$Name[i]=="soil_rechr_max") {        #soil_rechr_max
    values <- hru$soil_rechr_max
    tpl.txt<-paste("&  srm",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("srm%i = %.5f * srm_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"srm_fac = &   srm_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="soil_moist_max") {        #soil_moist_max
    values <- hru$soil_moist_max
    tpl.txt<-paste("&  smm",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("smm%i = %.5f * smm_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"smm_fac = &   smm_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="soil_rechr_init") {        #soil_rechr_init
    values <- hru$soil_rechr_init
  } else if(params.sort$Name[i]=="soil_moist_init") {        #soil_moist_init
    values <- hru$soil_moist_init

  } else if(params.sort$Name[i]=="sat_threshold") {         #sat_threshold
    values <- hru$sat_threshold
    tpl.txt<-paste("&  satth",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("satth%i = %.5f * satth_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"satth_fac = &   satth_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="dday_slope") {            #dday_slope
    values <- dday_slope
  } else if(params.sort$Name[i]=="dday_intcp") {            #dday_intcp
    values <- dday_intcp
  } else if(params.sort$Name[i]=="tmax_index") {            #tmax_index
    values <- tmax_index
  } else if(params.sort$Name[i]=="soil2gw_max") {            #soil2gw_max
    values <- soil2gw_max
    tpl.txt<-paste("&  s2gwmx",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("s2gwmx%i = %.5f * s2gwmx_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"s2gwmx_fac = &   s2gwmx_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="radadj_intcp") {          #radadj_intcp
    values <- radadj_intcp
  } else if(params.sort$Name[i]=="radadj_slope") {          #radadj_slope
    values <- radadj_slope
  } else if(params.sort$Name[i]=="jh_coef") {               #jh_coef
    values <- jh_coef
    tpl.txt<-paste("&  jhcoef",1:12,"    &",sep="")
    par2par.txt<-sprintf("jhcoef%i = %.5f * jhcoef_fac\n",1:12,as.numeric(values))
    cat(file=output_par2par_file,"jhcoef_fac = &   jhcoef_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="jh_coef_hru") {           #jh_coef_hru
    values <- jh_coef_hru
  } else if(params.sort$Name[i]=="tmax_adj") {              #tmax_adj
    values <- hru$tmax_adj
  } else if(params.sort$Name[i]=="tmin_adj") {              #tmin_adj
    values <- hru$tmin_adj
  } else if(params.sort$Name[i]=="snow_adj") {              #snow_adj
    values <- snow_adj
    tpl.txt<-paste("&  snwadj",1:(nrow(hru)*12),"    &",sep="")
    par2par.txt<-sprintf("snwadj%i = %.5f * snwadj_fac\n",1:(nrow(hru)*12),as.numeric(values))
    cat(file=output_par2par_file,"snwadj_fac = &   snwadj_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="rain_adj") {              #rain_adj
    values <- rain_adj
    tpl.txt<-paste("&  rnadj",1:(nrow(hru)*12),"    &",sep="")
    par2par.txt<-sprintf("rnadj%i = %.5f * rnadj_fac\n",1:(nrow(hru)*12),as.numeric(values))
    cat(file=output_par2par_file,"rnadj_fac = &   rnadj_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="adjmix_rain") {           #adjmix_rain
    values <- adjmix_rain

  # precip_dist2_prms parameters
  } else if(params.sort$Name[i]=="dist_max") {              #dist_max
    values <- dist_max
  } else if(params.sort$Name[i]=="hru_xlong") {             #hru_xlong
    values <- hru$hru_xlong
  } else if(params.sort$Name[i]=="hru_ylat") {              #hru_ylat
    values <- hru$hru_ylat
  } else if(params.sort$Name[i]=="max_psta") {              #max_psta
    values <- max_psta
  } else if(params.sort$Name[i]=="maxmon_prec") {           #maxmon_prec
    values <- maxmon_prec
  } else if(params.sort$Name[i]=="ppt_adj") {               #ppt_adj
    values <- ppt_adj
  } else if(params.sort$Name[i]=="psta_mon") {              #psta_mon
    values <- psta_mon
  } else if(params.sort$Name[i]=="psta_xlong") {            #psta_xlong
    values <- psta_xlong
  } else if(params.sort$Name[i]=="psta_ylat") {             #psta_ylat
    values <- psta_ylat
  } else if(params.sort$Name[i]=="rain_mon") {              #rain_mon
    values <- rain_mon
  } else if(params.sort$Name[i]=="snow_mon") {              #snow_mon
    values <- snow_mon
  } else if(params.sort$Name[i]=="rad_trncf") {             #rad_trncf
    values <- hru$rad_trncf
  } else if(params.sort$Name[i]=="hru_lat") {               #rad_trncf
    values <- hru$hru_lat
  } else if(params.sort$Name[i]=="subbasin_down") {         #subbasin_down
    values <- subbasin_down
  } else if(params.sort$Name[i]=="hru_subbasin") {          #hru_subbasin
    values <- hru$subbasin
  } else if(params.sort$Name[i]=="melt_look") {             #melt_look
    values <- melt_look
  } else if(params.sort$Name[i]=="freeh2o_cap") {           #freeh2o_cap
    values <- freeh2o_cap
  } else if(params.sort$Name[i]=="covden_sum") {            #covden_sum
    values <- hru$covden_sum
  } else if(params.sort$Name[i]=="covden_win") {            #covden_win
    values <- hru$covden_win
  } else if(params.sort$Name[i]=="tsta_elev") {             #tsta_elev
    values <- tsta_elev
  } else if(params.sort$Name[i]=="settle_const") {          #settle_const
    values <- settle_const
  } else if(params.sort$Name[i]=="tmax_allsnow") {          #tmax_allsnow
    values <- tmax_allsnow
  } else if(params.sort$Name[i]=="ssr2gw_rate") {           #ssr2gw_rate
    values <- hru$ssr2gw_rate
    tpl.txt<-paste("&  s2gw",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("s2gw%i = %.5f * s2gw_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"s2gw_fac = &   s2gw_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="ssr2gw_exp") {            #ssr2gw_exp
    values <- hru$ssr2gw_exp
    tpl.txt<-paste("&  s2gwe",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("s2gwe%i = %.5f * s2gwe_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"s2gwe_fac = &   s2gwe_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="ssrmax_coef") {            #ssrmax_coef
    values <- hru$ssrmax_coef
    tpl.txt<-paste("&  ssrmax",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("ssrmax%i = %.5f * ssrmax_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"ssrmax_fac = &   ssrmax_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="slowcoef_lin") {          #slowcoef_lin
    values <- hru$slowcoef_lin
    tpl.txt<-paste("&  s_lin",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("s_lin%i = %.5f * s_lin_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"s_lin_fac = &   s_lin_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="slowcoef_sq") {           #slowcoef_sq
    values <- hru$slowcoef_sq
    tpl.txt<-paste("&  s_sq",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("s_sq%i = %.5f * s_sq_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"s_sq_fac = &   s_sq_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="fastcoef_lin") {          #fastcoef_lin
    values <- hru$fastcoef_lin
    tpl.txt<-paste("&  f_lin",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("f_lin%i = %.5f * f_lin_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"f_lin_fac = &   f_lin_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="fastcoef_sq") {           #fastcoef_sq
    values <- hru$fastcoef_sq
    tpl.txt<-paste("&  f_sq",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("f_sq%i = %.5f * f_sq_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"f_sq_fac = &   f_sq_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="gwflow_coef") {           #gwflow_coef
    values <- hru$gwflow_coef
  } else if(params.sort$Name[i]=="gwstor_init") {           #gwstor_init
    values <- gwstor_init
  } else if(params.sort$Name[i]=="snarea_curve") {          #snarea_curve
    values <- snarea_curve
  } else if(params.sort$Name[i]=="snarea_thresh") {         #snarea_thresh
    values <- snarea_thresh
  } else if(params.sort$Name[i]=="snowinfil_max") {         #snowinfil_max
    values <- snowinfil_max
    tpl.txt<-paste("&  sn_infil",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("sn_infil%i = %.5f * sn_infil_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"sn_infil_fac = &   sn_infil_fac   &\n",append=TRUE)

  } else if(params.sort$Name[i]=="basin_area") {            #basin_area
    values <- basin_area

  } else if(params.sort$Name[i]=="gvr_cell_id") {           # gvr_cell_id
    values <- hrucell$gvr_cell_id
  } else if(params.sort$Name[i]=="gvr_cell_pct") {          # gvr_cell_pct
    values <- hrucell$gvr_cell_pct
  } else if(params.sort$Name[i]=="gvr_hru_id") {            # gvr_hru_id
    values <- hrucell$gvr_hru_id
  } else if(params.sort$Name[i]=="gvr_hru_pct") {          # gvr_hru_pct
    values <- hrucell$gvr_hru_pct

  } else if(params.sort$Name[i]=="gwc_col") {               # gwc_col
    values <- gwcell$gwc_col
  } else if(params.sort$Name[i]=="gwc_row") {               # gwc_row
    values <- gwcell$gwc_row

  } else if(params.sort$Name[i]=="local_reachid") {         # local_reachid
    values <- reach$local_reachid
  } else if(params.sort$Name[i]=="reach_segment") {         # reach_segment
    values <- reach$reach_segment
  } else if(params.sort$Name[i]=="segment_pct_area") {      # segment_pct_area
    values <- reach$segment_pct_area

  } else if(params.sort$Name[i]=="numreach_segment") {      # numreach_segment
    values <- segment$numreach_segment

  } else if(params.sort$Name[i]=="hru_segment") {           # hru_segment
    values <- hru$hru_segment

  } else if(params.sort$Name[i]=="mxsziter") {              # mxsziter
    values <- mxsziter

  } else if(params.sort$Name[i]=="pref_flow_den") {         #pref_flow_den
    values <- hru$pref_flow_den
    tpl.txt<-paste("&  pfd",1:nrow(hru),"    &",sep="")
    par2par.txt<-sprintf("pfd%i = %.5f * pfd_fac\n",1:nrow(hru),as.numeric(values))
    cat(file=output_par2par_file,"pfd_fac = &   pfd_fac   &\n",append=TRUE)
  }

  if(!params.sort$Name[i] %in% skip.params) {
    write_prms_parameter(fname=output_param_file,
                       parname=params.sort$Name[i],
                       dimname1=params.sort$Dimname_1[i],
                       dimname2=params.sort$Dimname_2[i],
                       type=params.sort$Type[i],
                       values=values)
    # if we have populated tpl.txt, write out to template files
    if(any(!is.na(tpl.txt))) {
      write_prms_parameter(fname=output_template_file,
                         parname=params.sort$Name[i],
                         dimname1=params.sort$Dimname_1[i],
                         dimname2=params.sort$Dimname_2[i],
                         type=params.sort$Type[i],
                         values=tpl.txt)
      cat(file=output_par2par_file,par2par.txt,append=TRUE)

    } else {
      write_prms_parameter(fname=output_template_file,
                         parname=params.sort$Name[i],
                         dimname1=params.sort$Dimname_1[i],
                         dimname2=params.sort$Dimname_2[i],
                         type=params.sort$Type[i],
                         values=values)
    }
  }
}

if(need.plots) {

pdf(file="PRMS_Parameter_Maps.pdf",width=10,height=8)

# need to add a "Z" column in order to make use of the makeProps function
hru_shp_PD$Z<-hru_shp_PD$forest.pct
palette(brewer.pal(9,"Greens"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=c(-0.01,10,20,30,40,50,60,70,80,101),propVals=c(1:9)),
   border="grey20",main="Percent Forest Cover")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:9),col=1:9,legend=c("0-10%","10-20%","20-30%",
    "30-40%","40-50%","50-60%","60-70%","70-80%",">80%"),bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# D soils
hru_shp_PD$Z<-hru_shp_PD$pct_D_soils
palette(brewer.pal(6,"YlOrBr"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=c(-0.01,10,20,30,40,50,100),propVals=c(1:6)),
   border="grey20",main="Percent D Soils")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:9),col=1:6,legend=c("0-10%","10-20%","20-30%","30-40%",
    "40-50%",">50%"),bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# aspect
hru_shp_PD$Z<-hru_shp_PD$aspect
palette(brewer.pal(11,"Spectral"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=11,propVals=c(1:11)),
   border="grey20",main="Aspect (CW degrees from North)")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:11),col=1:11,legend=c(levels(cut(hru$aspect,11))),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# OPEN WATER
hru_shp_PD$Z<-hru_shp_PD$pct_open_water
palette(brewer.pal(5,"Blues"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=c(0,2.5,5,10,15,100),propVals=c(1:5)),
   border="grey20",main="Percent Open Water")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:5),col=1:5,legend=c("0-2.5%","2.5-5%","5-10%","10-15%",">15%"),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# carea_max
hru_shp_PD$Z<-hru_shp_PD$carea_max
palette(brewer.pal(5,"Reds"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=c(0,.10,.25,.50,.75,1.00),propVals=c(1:5)),
   border="grey20",main="carea_max")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:5),col=1:5,legend=c("0-10%","10-25%","25-50%","50-75%",">75%"),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# covden_sum
hru_shp_PD$Z<-hru_shp_PD$covden_sum
palette(brewer.pal(5,"Greens"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=c(-0.001,.10,.25,.50,.75,1.00),propVals=c(1:5)),
   border="grey20",main="covden_sum")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:5),col=1:5,legend=c("0-10 in.","10-25 in.","25-50 in.","50-75 in.",">75 in."),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# covden_win
hru_shp_PD$Z<-hru_shp_PD$covden_win
palette(brewer.pal(5,"YlOrBr"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=c(-0.001,.10,.25,.50,.75,1.01),propVals=c(1:5)),
   border="grey20",main="covden_win")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:5),col=1:5,legend=c("0-10 in.","10-25 in.","25-50 in.","50-75 in.",">75 in."),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# soil_type
hru_shp_PD$Z<-hru_shp_PD$soil_type
palette(brewer.pal(4,"YlOrBr"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   propVals=c(1:4),breaks=4),
   border="grey20",main="soil_type")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:4),legend=c("1 (sand)","2 (silt)","3 (silt)","4 (clay)"),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# pct_imp
hru_shp_PD$Z<-hru_shp_PD$pct_imp
palette(brewer.pal(6,"Reds"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=c(-0.01,5,10,15,25,50,101),propVals=c(1:6)),
   border="grey20",main="hru_percent_imperv")
addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:6),col=1:6,legend=c("0-5%","5-10%","10-15%","15-25%","25-50%",">50%"),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# hru_slope
hru_shp_PD$Z<-hru_shp_PD$slope
palette(brewer.pal(7,"Reds"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=c(-0.01,.05,.10,.15,.20,.25,.50,1.01),propVals=c(1:7)),
   border="grey20",main="hru_slope")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:6),col=1:6,legend=c("0-5%","5-10%","10-15%","15-20%",
   "20-25%","25-50%",">50%"),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# srain_intcp
hru_shp_PD$Z<-hru_shp_PD$srain_intcp
palette(brewer.pal(6,"Blues"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=c(-0.01,0.025,.05,0.075,.10,.15,.20),propVals=c(1:6)),
   border="grey20",main="srain_intcp")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:6),col=1:6,legend=c("0-0.025 in.","0.025-0.05 in.","0.05-0.75 in.","0.75-0.1 in.",
   "0.1-0.15 in.","0.15-0.20 in."),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# wrain_intcp
hru_shp_PD$Z<-hru_shp_PD$wrain_intcp
palette(brewer.pal(6,"Blues"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=c(-0.01,0.025,.05,0.075,.10,.15,.20),propVals=c(1:6)),
   border="grey20",main="wrain_intcp")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:6),col=1:6,legend=c("0-0.025 in.","0.025-0.05 in.","0.05-0.75 in.","0.75-0.1 in.",
   "0.1-0.15 in.","0.15-0.20 in."),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# snow_intcp
hru_shp_PD$Z<-hru_shp_PD$snow_intcp
palette(brewer.pal(6,"Blues"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=c(-0.01,0.025,.05,0.075,.10,.15,.20),propVals=c(1:6)),
   border="grey20",main="snow_intcp")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:6),col=1:6,legend=c("0-0.025 in.","0.025-0.05 in.","0.05-0.75 in.","0.75-0.1 in.",
   "0.1-0.15 in.","0.15-0.20 in."),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# smidx_coef
hru_shp_PD$Z<-hru_shp_PD$smidx_coef
palette(brewer.pal(6,"Purples"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=c(-0.01,0.00025,.0005,0.001,.005,0.01,1.0),propVals=c(1:6)),
   border="grey20",main="smidx_coef")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:6),col=1:6,legend=c("0-0.00025","0.00025-0.0005",
   "0.0005-0.001","0.001-0.005","0.005-0.01",">0.01"),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# smidx_exp
hru_shp_PD$Z<-hru_shp_PD$smidx_exp
palette(brewer.pal(9,"PuBuGn"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=9,propVals=c(1:9)),
   border="grey20",main="smidx_exp")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:9),col=1:9,legend=c(levels(cut(hru$smidx_exp,9))),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# smidx_exp
hru_shp_PD$Z<-hru_shp_PD$depth2gw
palette(brewer.pal(9,"Blues"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=9,propVals=c(1:9)),
   border="grey20",main="Depth to groundwater")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:9),col=1:9,legend=c(levels(cut(hru$depth2gw,9))),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# soil_rechr_max
hru_shp_PD$Z<-hru_shp_PD$soil_rechr_max
palette(brewer.pal(9,"Blues"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=9,propVals=c(1:9)),
   border="grey20",main="soil_rechr_max (inches)")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:9),col=1:9,legend=c(levels(cut(hru$soil_rechr_max,9))),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# soil_moist_max
hru_shp_PD$Z<-hru_shp_PD$soil_moist_max
palette(brewer.pal(9,"Greens"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=9,propVals=c(1:9)),
   border="grey20",main="soil_moist_max (inches)")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:9),col=1:9,legend=c(levels(cut(hru$soil_moist_max,9))),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# sat_threshold
hru_shp_PD$Z<-hru_shp_PD$sat_threshold
palette(brewer.pal(9,"RdPu"))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=9,propVals=c(1:9)),
   border="grey20",main="sat_threshold (inches)")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:9),col=1:9,legend=c(levels(cut(hru$sat_threshold,9))),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# tmax_adj
hru_shp_PD$Z<-hru_shp_PD$tmax_adj
palette(rev(brewer.pal(9,"RdBu")))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=9,propVals=c(1:9)),
   border="grey20",main="tmax_adj (degrees F)")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:9),col=1:9,legend=c(levels(cut(hru$tmax_adj,9))),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# tmin_adj
hru_shp_PD$Z<-hru_shp_PD$tmin_adj
palette(rev(brewer.pal(9,"RdBu")))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=9,propVals=c(1:9)),
   border="grey20",main="tmin_adj (degrees F)")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:9),col=1:9,legend=c(levels(cut(hru$tmin_adj,9))),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# rad_trncf
hru_shp_PD$Z<-hru_shp_PD$rad_trncf
palette(rev(brewer.pal(9,"RdBu")))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=9,propVals=c(1:9)),
   border="grey20",main="rad_trncf (radiation transmission coefficient)")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:9),col=1:9,legend=c(levels(cut(hru$rad_trncf,9))),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# gagedef for Black Earth
hru_shp_PD$Z<-hru_shp_PD$bec_at_be
palette(rev(brewer.pal(4,"RdBu")))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=4,propVals=c(1:4)),
   border="grey20",main="Gagedefs for Black Earth Creek at Black Earth")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:4),col=1:4,legend=c(levels(cut(hru$bec_at_be,4))),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# ssr2gw_rate
hru_shp_PD$Z<-hru_shp_PD$ssr2gw_rate
palette(rev(brewer.pal(9,"RdBu")))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=9,propVals=c(1:9)),
   border="grey20",main="ssr2gw_rate")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:9),col=1:9,legend=c(levels(cut(hru$ssr2gw_rate,9))),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# slowcoef_lin
hru_shp_PD$Z<-hru_shp_PD$slowcoef_lin
palette(rev(brewer.pal(9,"RdBu")))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=9,propVals=c(1:9)),
   border="grey20",main="slowcoef_lin")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:9),col=1:9,legend=c(levels(cut(hru$slowcoef_lin,9))),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# fastcoef_lin
hru_shp_PD$Z<-hru_shp_PD$fastcoef_lin
palette(rev(brewer.pal(9,"RdBu")))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=9,propVals=c(1:9)),
   border="grey20",main="fastcoef_lin")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:9),col=1:9,legend=c(levels(cut(hru$fastcoef_lin,9))),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# slowcoef_sq
hru_shp_PD$Z<-hru_shp_PD$slowcoef_sq
palette(rev(brewer.pal(9,"RdBu")))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=9,propVals=c(1:9)),
   border="grey20",main="slowcoef_sq")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:9),col=1:9,legend=c(levels(cut(hru$slowcoef_sq,9))),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

# fastcoef_sq
hru_shp_PD$Z<-hru_shp_PD$fastcoef_sq
palette(rev(brewer.pal(9,"RdBu")))
plotPolys(hru_shp_PS,polyProps=makeProps(pdata=hru_shp_PD,
   breaks=9,propVals=c(1:9)),
   border="grey20",main="fastcoef_sq")
 addPolys(SFR_PS,col="dodgerblue",border=NA)
legend("bottomright",fill=c(1:9),col=1:9,legend=c(levels(cut(hru$fastcoef_sq,9))),
   bg="white",inset=c(0.05,0.05),cex=0.8)
box()

dev.off()

} #end if(need.plots)

if(need.gagedefs) {

  hru$bec_at_be[hru$bec_at_be==2]<-5406500
  hru$brewery_ck[hru$brewery_ck==2]<-5406470
  hru$garfoot_ck[hru$garfoot_ck==2]<-5406491
  hru$vermont_ck[hru$vermont_ck==2]<-54065145
  hru$bec_at_mazo[hru$bec_at_mazo==2]<-5406540
  hru$pheas_br[hru$pheas_br==2]<-5427948

  cat(file="gagedefs.txt",
    "HRU AREA AREA_ACRES NONE NONE BEC_AT_BE BEC_AT_BRE BEC_AT_GAR BEC_AT_MAZ VERMONT_CK PHEASBR\n")
  for (i in 1:nrow(hru)) {
    cat(file="gagedefs.txt",hru$HRU[i],hru$area[i],hru$area.acres[i],"NA","NA",
      hru$bec_at_be[i],hru$brewery_ck[i],hru$garfoot_ck[i],hru$vermont_ck[i],
      hru$bec_at_mazo[i],sep="\t",append=TRUE)
    cat(file="gagedefs.txt","\t",hru$pheas_br[i],"\n",sep="",append=TRUE)
  }
} # end if need.gagedefs

cat(file=output_par2par_file,"* template and model input files\n",append=TRUE)
cat(file=output_par2par_file,"BEC_PRMS_param.tpl bec_pest.params\n",append=TRUE)


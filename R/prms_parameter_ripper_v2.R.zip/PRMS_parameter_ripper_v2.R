library( svDialogs )

output_filename<-"parameter_plots"

valtxt <- ""

# if "F", no gui will be offered to the user
enable_gui <- FALSE

# offer GUI to change directory
if(enable_gui) {
  dirname <- svDialogs::dlgDir(default=getwd(),
    title="Choose a working directory")$res
  setwd(dirname)
}

# set the names of the input, output filenames
if(enable_gui) {
  parameter_file<-svDialogs::dlgOpen(filters =  matrix(c("All","PRMS param files",
     "*.*","*.param;*.params"),nrow=2,ncol=2),
      title="Choose the PRMS parameter file to rip")$res
} else {
  parameter_file<-"params"
}

# set the names of the DEFAULT PARAMETER file
if(enable_gui) {
  default_parameter_file<-svDialogs::dlgOpen(filters =  matrix(c("All","PRMS param files",
     "*.*","*.param;*.params"),nrow=2,ncol=2),
      title="Choose the DEFAULT PRMS parameter file to rip")$res
} else {
  default_parameter_file<-"control.par.name"
}


# call functions that read in output from PRMS with -print option
default_dims       <- get_prms_dimensions(default_parameter_file)
default_parameters <- get_prms_parameters(default_parameter_file)

strmatch<-0
n <- 0

# slurp ENTIRE parameter file into memory
s1 <- scan(file=parameter_file,what=character(256), sep="\n")

param <- grep(glob2rx("** Parameters **"),s1[1:length(s1)],ignore.case=TRUE)
#param<-grep("Parameters",s1[1:length(s1)])
nhru <- match("nhru",s1[1:max(param)])

# find PARAMETER NAMES
param_names_idx<-grep("####",s1[1:length(s1)]) + 1

# redefine to include only indices that come *after* the first
# occurrance of "Parameters" in the input file
param_names_idx<-param_names_idx[param_names_idx>max(param)]
temp_param <- s1[param_names_idx]
temp_param<- unlist(strsplit(temp_param," "))
len_temp <- length(temp_param)
param_names <- temp_param[seq(1,len_temp,2)]    # extract only odd elements

# in cases where the parameter width has been left off, this
# will subtract on from the index to point to the correct value
offset<-ifelse(!is.na(as.numeric(s1[param_names_idx + 2])),0,-1)

param_numdim_idx<-param_names_idx + 2 + offset
param_numdim<-as.numeric(s1[param_numdim_idx])

param_dim1_idx<-param_names_idx + 3 + offset
param_dim1<-s1[param_dim1_idx]

param_dim2_idx<-param_names_idx + 4 + offset
param_dim2<-s1[param_dim2_idx]

#retroactively nuke all parameters that have only one dimension
param_dim2_idx[param_numdim==1]<-NA
param_dim2[param_numdim==1]<-"none"

param_length_idx<-param_names_idx + param_numdim + 3 + offset
param_length<-as.numeric(s1[param_length_idx])

param_begin_idx<-param_names_idx + param_numdim + 5 + offset
param_end_idx<-param_begin_idx + param_length - 1

alpha_order<-order(param_dim1,param_dim2,param_names)

dimname<-"dummy"
dimname2<-"dummy"

# now lets do some plotting

pdf(file = paste(output_filename,".pdf",sep=""),
    width = 11, height = 8.5, bg = "white")

layout(matrix(c(1,2,3,4),2 , 2, byrow=TRUE))

par(mar=c(5,5,4,3))

# iterate through the list of all parameters, sorted by dimension names
for (i in alpha_order) {

   if(any(default_parameters$Name %in% param_names[i])) {
     dparm <- subset(default_parameters, default_parameters$Name %in% param_names[i])
   } else {
     dparm <- NA
   }

   new_dimname<-param_dim1[i]
   new_dimname2<-param_dim2[i]
   if(new_dimname != dimname | new_dimname2 != dimname2) {
     if(new_dimname2 != "none") {
       cat(sprintf("\n\n\t\t\t\tdimensions: %s  %s\n",new_dimname, new_dimname2))
       subtxt<-paste("dimensions:",new_dimname, new_dimname2,sep="  ")
     } else {
       cat(sprintf("\n\n\t\t\t\tdimension: %s\n",new_dimname))
       subtxt<-paste("dimension:",new_dimname,sep="  ")
     }
     cat(sprintf("%25s\t%11s\t%11s\t%11s\t%11s\t%11s\n","PARAMETER","0%","25%","50%",
       "75%","100%"))
     cat(rep("-",110),"\n",sep="")
     if(new_dimname != dimname ) dimname<-new_dimname
     if(new_dimname2 != dimname2 ) dimname2<-new_dimname2
   }

   cat(sprintf("%25s\t",param_names[i]))
   cat(sprintf("%10.4g\t",
      quantile(as.numeric(s1[param_begin_idx[i]:param_end_idx[i]]))))
   cat("\n")

   dat<-as.numeric(s1[param_begin_idx[i]:param_end_idx[i]])

   if(length(unique(dat))>1) {
     hist(dat, main=param_names[i], xlab=NA , col="steelblue", tcl=0.3)
     mtext(side=1,text=paste("n =",length(dat)),line=2,cex=0.8)
     if(!is.na(dparm)) {
       abline(v=dparm$Default, col="navy",lty=2)
       if(dparm$Type == "float") {
         valtxt <- sprintf("   default: %12.3f",as.numeric(dparm$Default))
       } else if(dparm$Type == "long") {
         valtxt <- sprintf("   default: %12i",as.numeric(dparm$Default))
       } else {
         valtxt <- ""
       }
     }
     mtext(side=3,text=paste(subtxt,valtxt))
     box()

     qqnorm(dat, main=param_names[i], col="red", tcl=0.3)
     if(!is.na(dparm)) {
       abline(h=dparm$Default, col="navy",lty=2)
     }

     box()

   } else {
     dotchart(unique(dat), main=param_names[i], xlab=NA , col="steelblue", tcl=0.3,
        pch=19,cex=1.3)
     mtext(side=1,text=paste("n =",length(dat), "(single-valued)"),line=2,cex=0.8)
     text(x=dat,y=1.2,dat,col="steelblue",font=2,cex=1.2)
     if(!is.na(dparm)) {
       abline(v=dparm$Default, col="navy",lty=2)
       if(dparm$Type == "float") {
         valtxt <- sprintf("   default: %12.3f",as.numeric(dparm$Default))
       } else if(dparm$Type == "long") {
         valtxt <- sprintf("   default: %12i",as.numeric(dparm$Default))
       } else {
         valtxt <- ""
       }
     }
     mtext(side=3,text=paste(subtxt,valtxt))
     box()

    plot(dat, axes=FALSE,type="n",ylab=NA,xlab=NA)
   }

}

dev.off()
#if(strmatch>0) cat(paste("Found a match!!  strmatch=",strmatch,"\n\n",s1))
